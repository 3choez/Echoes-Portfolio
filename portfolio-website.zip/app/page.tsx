"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import Image from "next/image"

interface PortfolioItem {
  id: number
  src: string
  alt: string
  category: "2d-art" | "3d-models" | "faces"
}

const portfolioItems: PortfolioItem[] = [
  // 2D Art
  { id: 1, src: "https://imgur.com/LpqDrXT.png", alt: "2D Art 1", category: "2d-art" },
  { id: 2, src: "https://imgur.com/sWb3s4I.png", alt: "2D Art 2", category: "2d-art" },
  { id: 3, src: "https://i.imgur.com/lMKE84d.png", alt: "2D Art 3", category: "2d-art" },

  // 3D Models (only 3 now)
  { id: 4, src: "https://i.imgur.com/JXyiUnp.jpeg", alt: "3D Model 1", category: "3d-models" },
  { id: 5, src: "https://i.imgur.com/pb3jYGY.jpeg", alt: "3D Model 2", category: "3d-models" },
  { id: 6, src: "https://i.imgur.com/Sc9X7aM.png", alt: "3D Model 3", category: "3d-models" },
]

export default function Portfolio() {
  const [phase, setPhase] = useState<"paused" | "playing" | "fading" | "finished">("paused")
  const [showOverlay, setShowOverlay] = useState(false)
  const [showBackground, setShowBackground] = useState(false)
  const [showImages, setShowImages] = useState(false)
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null)
  const [showFacesText, setShowFacesText] = useState(false)
  const [typingText, setTypingText] = useState("")
  const [audioInitialized, setAudioInitialized] = useState(false)
  const [bgMusicVolume, setBgMusicVolume] = useState(0)

  const gifAudioRef = useRef<HTMLAudioElement>(null)
  const backgroundAudioRef = useRef<HTMLAudioElement>(null)
  const hoverClickAudioRef = useRef<HTMLAudioElement>(null)
  const gifClickAudioRef = useRef<HTMLAudioElement>(null)
  const typingAudioRef = useRef<HTMLAudioElement>(null)
  const typingIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const lastHoverTime = useRef<number>(0)
  const volumeFadeRef = useRef<NodeJS.Timeout | null>(null)

  const pricingText = `* Faces are around, 10-20 Euros, While Concept drawings may cost more than or around 15-20 Euros.
Models can vary widely depnding on the type, but they are typically 80-100+ Euros, but if it's simple it's 40-60+ Euros.

Also You have to wait at least 5+ days for your commission to be done.
Please allow the agreed-upon time for completion.
Please keep in mind that this is a personal business, and as such, I reserve the right to either accept or deny your request based on my discretion.`

  // Initialize audio on first user interaction
  useEffect(() => {
    const initializeAudio = () => {
      if (!audioInitialized) {
        // Pre-load all audio elements
        const audioElements = [
          gifAudioRef.current,
          backgroundAudioRef.current,
          hoverClickAudioRef.current,
          gifClickAudioRef.current,
          typingAudioRef.current,
        ]

        // Load audio files
        audioElements.forEach((audio) => {
          if (audio) {
            audio.load()
          }
        })

        setAudioInitialized(true)
        console.log("Audio initialized on user interaction")

        // Remove event listeners after initialization
        document.removeEventListener("click", initializeAudio)
        document.removeEventListener("keydown", initializeAudio)
      }
    }

    // Add event listeners for first interaction
    document.addEventListener("click", initializeAudio)
    document.addEventListener("keydown", initializeAudio)

    return () => {
      document.removeEventListener("click", initializeAudio)
      document.removeEventListener("keydown", initializeAudio)
    }
  }, [audioInitialized])

  const safePlayAudio = useCallback(async (audioRef: React.RefObject<HTMLAudioElement>) => {
    if (audioRef.current) {
      try {
        // Ensure the audio is ready
        audioRef.current.currentTime = 0
        const playPromise = audioRef.current.play()

        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.log("Audio play prevented:", error)
          })
        }
      } catch (error) {
        // Silently handle audio play errors
        console.log("Audio play error:", error)
      }
    }
  }, [])

  const safePauseAudio = useCallback((audioRef: React.RefObject<HTMLAudioElement>) => {
    if (audioRef.current && !audioRef.current.paused) {
      try {
        audioRef.current.pause()
        audioRef.current.currentTime = 0
      } catch (error) {
        console.log("Audio pause error:", error)
      }
    }
  }, [])

  const fadeInBackgroundMusic = useCallback(() => {
    // Start with volume 0
    if (backgroundAudioRef.current) {
      backgroundAudioRef.current.volume = 0
      safePlayAudio(backgroundAudioRef)

      // Clear any existing fade interval
      if (volumeFadeRef.current) {
        clearInterval(volumeFadeRef.current)
      }

      // Gradually increase volume
      let vol = 0
      volumeFadeRef.current = setInterval(() => {
        if (backgroundAudioRef.current) {
          vol += 0.01
          if (vol >= 0.3) {
            vol = 0.3
            if (volumeFadeRef.current) {
              clearInterval(volumeFadeRef.current)
              volumeFadeRef.current = null
            }
          }
          backgroundAudioRef.current.volume = vol
          setBgMusicVolume(vol)
        }
      }, 100) // Adjust every 100ms for a smooth 3-second fade-in
    }
  }, [safePlayAudio])

  const playHoverClickSound = useCallback(() => {
    const now = Date.now()
    // Debounce hover sounds to prevent rapid firing
    if (now - lastHoverTime.current > 100) {
      lastHoverTime.current = now
      safePlayAudio(hoverClickAudioRef)
    }
  }, [safePlayAudio])

  const handleGifClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    console.log("GIF clicked, current phase:", phase)

    if (phase === "paused") {
      console.log("Starting GIF animation")
      setPhase("playing")

      // Play GIF click sound
      safePlayAudio(gifClickAudioRef)

      // Play original GIF sound
      safePlayAudio(gifAudioRef)

      // Show overlay image after a brief delay
      setTimeout(() => {
        setShowOverlay(true)
      }, 500)

      // Start fading out both elements
      setTimeout(() => {
        console.log("Starting fade out")
        setPhase("fading")

        // After fade out completes, show website
        setTimeout(() => {
          console.log("Fade out finished, showing website")
          setPhase("finished")

          // Start fading in background after a brief delay
          setTimeout(() => {
            setShowBackground(true)

            // Start background music with fade-in
            fadeInBackgroundMusic()

            // Fade in images after background starts fading
            setTimeout(() => {
              setShowImages(true)
            }, 3000) // Slower fade-in for images
          }, 1000)
        }, 2000) // Wait for fade out to complete
      }, 3000) // Show overlay for 3 seconds before fading
    }
  }

  const getCategoryImage = (category: string, isHovered = false) => {
    if (isHovered) {
      switch (category) {
        case "2d-art":
          return "/2d-art-hover.png"
        case "3d-models":
          return "/3d-models-hover.png"
        case "faces":
          return "/faces-hover.png"
        default:
          return ""
      }
    }

    switch (category) {
      case "2d-art":
        return "/2d-art.png"
      case "3d-models":
        return "/3d-models.png"
      case "faces":
        return "/faces.png"
      default:
        return ""
    }
  }

  const groupedItems = portfolioItems.reduce(
    (acc, item) => {
      if (!acc[item.category]) {
        acc[item.category] = []
      }
      acc[item.category].push(item)
      return acc
    },
    {} as Record<string, PortfolioItem[]>,
  )

  const handleFacesClick = () => {
    // Play hover/click sound
    playHoverClickSound()

    if (!showFacesText) {
      setShowFacesText(true)
      setTypingText("")

      // Start typing sound
      safePlayAudio(typingAudioRef)

      // Start typing animation
      let currentIndex = 0
      typingIntervalRef.current = setInterval(() => {
        if (currentIndex < pricingText.length) {
          setTypingText(pricingText.slice(0, currentIndex + 1))
          currentIndex++
        } else {
          if (typingIntervalRef.current) {
            clearInterval(typingIntervalRef.current)
            typingIntervalRef.current = null
          }
          // Stop typing sound when text is complete
          safePauseAudio(typingAudioRef)
        }
      }, 30) // Adjust speed here (lower = faster)
    } else {
      setShowFacesText(false)
      setTypingText("")
      // Clear typing interval and stop sound
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current)
        typingIntervalRef.current = null
      }
      safePauseAudio(typingAudioRef)
    }
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background Image */}
      <div
        className={`fixed inset-0 transition-opacity duration-5000 z-0 ${showBackground ? "opacity-100" : "opacity-0"}`}
        style={{
          backgroundImage: "url('/background.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />

      {/* Audio Elements */}
      <audio ref={gifAudioRef} preload="auto">
        <source src="/gif-sound.mp3" type="audio/mpeg" />
      </audio>

      <audio ref={hoverClickAudioRef} preload="auto">
        <source src="/hover-click-sound.mp3" type="audio/mpeg" />
      </audio>

      <audio ref={gifClickAudioRef} preload="auto">
        <source src="/gif-click-sound.mp3" type="audio/mpeg" />
      </audio>

      <audio ref={typingAudioRef} preload="auto" loop>
        <source src="/typing-sound.mp3" type="audio/mpeg" />
      </audio>

      {/* Background Music */}
      <audio ref={backgroundAudioRef} preload="auto" loop>
        <source src="/background-music.mp3" type="audio/mpeg" />
      </audio>

      {/* GIF Section - Only show if not finished */}
      {phase !== "finished" && (
        <div className="fixed inset-0 flex items-center justify-center z-50">
          {/* Container for GIF with larger area to prevent cropping */}
          <div
            className={`cursor-pointer transition-all duration-2000 select-none relative z-50 ${
              phase === "fading" ? "opacity-0" : "opacity-100"
            }`}
            onClick={handleGifClick}
            style={{
              width: "400px", // Larger container to prevent cropping
              height: "400px", // Larger container to prevent cropping
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              position: "relative",
            }}
          >
            {/* SAVE Point GIF */}
            <img
              src="/save-point.gif"
              alt="SAVE Point"
              width={200}
              height={200}
              className="rounded-lg absolute drop-shadow-2xl"
              style={{
                objectFit: "cover",
                top: "100px", // Center in the container
                left: "100px", // Center in the container
                filter: "drop-shadow(0 0 10px rgba(0, 0, 0, 0.5))",
              }}
            />

            {/* Overlay Image that fades in above the GIF */}
            {showOverlay && (
              <img
                src="/overlay-image.png"
                alt="Overlay"
                className={`absolute rounded-lg transition-opacity duration-1000 ${
                  phase === "fading" ? "opacity-0" : "opacity-100"
                }`}
                style={{
                  objectFit: "contain",
                  width: "350px", // Increased from 300px
                  height: "350px", // Increased from 300px
                  top: "-120px", // Moved higher from -20px
                  left: "25px", // Adjusted to center the larger image
                  filter: "drop-shadow(0 0 15px rgba(0, 0, 0, 0.7))",
                }}
              />
            )}
          </div>
        </div>
      )}

      {/* Portfolio Content */}
      <div className={`relative z-10 transition-opacity duration-4000 ${showImages ? "opacity-100" : "opacity-0"}`}>
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex justify-center mb-16">
            <img
              src="https://i.imgur.com/sJEgrnn.png"
              alt="My Portfolio"
              className="h-20"
              style={{ filter: "drop-shadow(0 0 15px rgba(0, 0, 0, 0.7))" }}
            />
          </div>

          {Object.entries(groupedItems).map(([category, items]) => (
            <section key={category} className="mb-16">
              <div
                className="flex justify-center mb-8"
                onMouseEnter={() => {
                  setHoveredCategory(category)
                  playHoverClickSound()
                }}
                onMouseLeave={() => setHoveredCategory(null)}
                onClick={playHoverClickSound}
              >
                <img
                  src={getCategoryImage(category, hoveredCategory === category) || "/placeholder.svg"}
                  alt={getCategoryImage(category)}
                  className="h-16 transition-all duration-300"
                  style={{ filter: "drop-shadow(0 0 15px rgba(0, 0, 0, 0.7))" }}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8 justify-items-center">
                {items.map((item, index) => (
                  <div
                    key={item.id}
                    className={`transition-all duration-1000 transform ${
                      showImages ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                    }`}
                    style={{
                      transitionDelay: `${index * 300}ms`,
                    }}
                  >
                    <div className="group cursor-pointer">
                      <div
                        className="relative overflow-hidden rounded-lg transition-all duration-300 group-hover:scale-110"
                        style={{
                          filter: "drop-shadow(0 0 20px rgba(0, 0, 0, 0.8))",
                          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.9)",
                        }}
                      >
                        <Image
                          src={item.src || "/placeholder.svg"}
                          alt={item.alt}
                          width={300}
                          height={300}
                          className="w-full h-auto object-cover"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}

          {/* Special Faces Section */}
          <section className="mb-16">
            <div
              className="flex justify-center mb-8 cursor-pointer"
              onMouseEnter={() => {
                setHoveredCategory("faces")
                playHoverClickSound()
              }}
              onMouseLeave={() => setHoveredCategory(null)}
              onClick={handleFacesClick}
            >
              <img
                src={getCategoryImage("faces", hoveredCategory === "faces") || "/placeholder.svg"}
                alt="Faces"
                className="h-16 transition-all duration-300"
                style={{ filter: "drop-shadow(0 0 15px rgba(0, 0, 0, 0.7))" }}
              />
            </div>

            {showFacesText && (
              <div
                className={`flex justify-center transition-opacity duration-1000 ${showImages ? "opacity-100" : "opacity-0"}`}
              >
                <div
                  className="w-full max-w-4xl h-64 bg-black text-white border-2 border-white p-6 pixel-font"
                  style={{
                    fontSize: "12px",
                    lineHeight: "1.8",
                    filter: "drop-shadow(0 0 10px rgba(255, 255, 255, 0.3))",
                  }}
                >
                  {typingText}
                  <span className="animate-pulse">|</span>
                </div>
              </div>
            )}
          </section>
          {/* Bottom left corner image */}
          <div className="fixed bottom-4 left-8 z-20">
            <img
              src="https://i.imgur.com/dwHDf9U.png"
              alt="Corner decoration"
              className="w-24 h-auto opacity-50"
              style={{ filter: "drop-shadow(0 0 5px rgba(0, 0, 0, 0.5))" }}
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        @import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap');
        
        .pixel-font {
          font-family: 'Press Start 2P', 'Courier New', monospace;
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.8);
        }
        .duration-3000 {
          transition-duration: 3000ms;
        }
        .duration-4000 {
          transition-duration: 4000ms;
        }
        .duration-5000 {
          transition-duration: 5000ms;
        }
      `}</style>
    </div>
  )
}
